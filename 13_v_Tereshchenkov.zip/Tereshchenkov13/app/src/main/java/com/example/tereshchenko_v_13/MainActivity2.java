package com.example.tereshchenko_v_13;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {

    Button but2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView buttonBack = (TextView) findViewById(R.id.but2);
        but2 = (Button) findViewById(R.id.but2);
        buttonBack.setOnClickListener(this);
        but2.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.but2:
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:12345"));
                startActivity(intent);

        }
    }


}